#!/bin/bash

rm reports/aggregated/tests.json >/dev/null 2>&1

rm reports/grading/res_*.txt >/dev/null 2>&1

touch reports/aggregated/tests.json

# Propagate any errors
#set -e

# Compile the program to be used for unit-tests
./5a_test_group.sh -m "grading/tests.txt" -t 0.1 -l 64

#Stop propagating errors
#set +e
